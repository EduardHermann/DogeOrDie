English:
"DogeOrDieMultiplayer" is a multiplayer game. At best, it should be played in pairs.
-> each player selects a rocket and controls it
-> to control the red rocket the keys W, A, S, D have to be pressed
-> to control the blue rocket the arrow keys have to be pressed
The goal of the game is to win more rounds than your opponent.
A round victory is achieved if one of the two players has no more life points.

To play this game you need at least Java 1.8 or a more recent Java version.
If you have a valid Java version you can double click on the "RUN.bat" file to start the game.

Deutsch:
"DogeOrDieMultiplayer" ist ein multiplayer-Spiel. Es sollte bestenfalls zu zweit gespielt werden.
-> jeder Spieler wählt eine Rakete aus und steuert diese
-> um die rote Rakete zu steuern müssen die Tasten W, A, S, D gedrückt werden
-> um die blaue Rakete zu steuern müssen die Pfeiltasten gedrückt werden
Das Ziehl des Spieles ist es, mehr Runden als der jeweilige Gegner zu gewinnen.
Ein Rundensieg wird erziehlt, wenn einer der beiden Spieler keine Lebenspunkte
mehr besitzen.

Um dieses Spiel spielen zu können benötigen Sie mindestens Java 1.8 oder eine aktuellere Java Version.
Falls sie eine gültige Java Version besitzen können Sie auf die "RUN.bat" Datei doppelklicken, um das Spiel
zu starten.

Java 8:
https://www.java.com/de/download/

