English:
"DogeOrDieSingleplayer" is a singleplayer game. At best, it should be played alone.
-> to control the rocket the keys W, A, S, D have to be pressed
The goal of the game is to reach a huge Timer count.

To play this game you need at least Java 1.8 or a more recent Java version.
If you have a valid Java version you can double click on the "RUN.bat" file to start the game.

Deutsch:
"DogeOrDieSingleplayer" ist ein singleplayer Spiel. Es sollte bestenfalls alleine gespielt werden.
-> um die Rakete zu steuern müssen die Tasten W, A, S, D gedrückt werden
Das Ziehl des Spieles ist es, eine möglichst hohe Timer Anzahl zu erreichen.

Um dieses Spiel spielen zu können benötigen Sie mindestens Java 1.8 oder eine aktuellere Java Version.
Falls sie eine gültige Java Version besitzen können Sie auf die "RUN.bat" Datei doppelklicken, um das Spiel
zu starten.

Java 8:
https://www.java.com/de/download/